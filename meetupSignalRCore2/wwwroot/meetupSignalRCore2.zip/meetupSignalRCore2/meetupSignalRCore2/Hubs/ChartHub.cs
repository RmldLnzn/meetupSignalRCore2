﻿using Microsoft.AspNetCore.SignalR;
using System.Threading.Tasks;

namespace meetupSignalRCore2.Hubs
{
    public class ChartHub : Hub
    {
    }
}